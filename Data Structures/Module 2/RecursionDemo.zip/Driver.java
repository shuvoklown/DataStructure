import java.util.*;

public class Driver {
	
	public static void main(String[] args) {
		RecursionTest rt = new RecursionTest();
		Date d;
		long t1;
		
		GUI theGUI = new GUI();
		theGUI.registerModel(rt);

		//FractalStar f = new FractalStar(512);
		
	}
	
}